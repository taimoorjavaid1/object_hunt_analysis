#!/usr/bin/env python
# coding: utf-8

# ### Problem Statement

# Does failing a level increase the risk of churn? (Churn is the proportion of players who stop playing the game, i.e do not progress.)
# 

# ### Objectives
# Assume that the customers will be game designers who will use this report to decide whether failing a level increases the risk of churn for this game.
# You should start with simple analyses and techniques before exploring more advanced ones.
# Your short report should take the following format:
# <ul>Key results: Brief summary on the main takeaways and conclusions.</ul>
# <ul>Introduction: Outline the aims and objectives of the analysis.</ul>
# <ul>Methodology: Describe any definitions, techniques and statistical methods used.</ul>
# <ul>Results: Display key findings using clear data visualisations, tables and bullet points.</ul>
# 
# 

# ### Datasets description
# There are two datasets provided:
# 
# ##### players.csv:
# Description: 
# Event sent when player installed the app and contains information on the characteristics of the player.
# Columns:
# <li>install_datetime: The date and time at which the player installed the app. (UTC)</li>
# <li>player_id: A unique identifier for each player.</li>
# <li>platform: The platform on which the player has installed the app.</li>
# <li>country: The two digit country code representing the country of install.</li>
# <li>screen_size: The diagonal screen size in inches. </li>
# <li>system_memory: The amount of RAM on the system in MB.</li>
# 
# #### level_progress.csv:
# Description: 
# Event sent when player progresses through the levels and stages in the app.
# Columns:
# <li>event_datetime: The date and time at which the event was received (UTC) </li>
# <li>player_id: A unique identifier for each player.</li>
# <li>level_number: The level number the event corresponds to. </li>
# <li>stage_number: The stage number the event corresponds to. A stage is a subsection of a level (i.e. a level will be split into     a number of stages). For more information on level and stages see Appendix.</li>
# <li>status: The outcome the event corresponds to:
# <ul>‘start’: Sent when a player starts a stage within a level in a session. This can be re-sent for the same level if a player reboots the app and restarts the stage.</ul>
#     <ul>‘fail’: Sent when a player fails a stage within a level. In this app, a player fails when they are caught by the hunter.     Failing results in the player receiving negative feedback text and will progress onto the following stage.</ul>
# <ul>‘complete’: Sent when a player successfully completes a stage within a level and is eligible to progress onto the next level.</ul></li>
# <li>session_id: A unique identifier for the session in which the event was produced. A session is defined as the period of time a player plays the app, it starts when they open the app and ends when they close the app. A player can play for multiple levels and stages in a session.</li>
# 
# <b>You should use the player_id columns in each file to link players with their level progress information. </b>
# 

# ### Importing the necessary libraries

# In[1]:


import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import seaborn as sns
import matplotlib.pyplot as plt


# ### Loading the data

# In[2]:


players = pd.read_csv('players.csv')
level_progress = pd.read_csv('level_progress.csv')


# ### Exploring the data

# In[3]:


players.head()


# In[4]:


level_progress.head()


# ### Explonarity Analysis

# In[5]:


# Check for missing data in players.csv dataset
print(players.isnull().sum())


# In[6]:


# Check for duplicate data in players.csv dataset
print(players.duplicated().sum())


# In[7]:


# Check for missing data in level_progress.csv dataset
print(level_progress.isnull().sum())


# In[8]:


# Check for duplicate data in level_progress.csv dataset
print(level_progress.duplicated().sum())


# In[9]:


# Calculate summary statistics for players.csv
print(players.describe())


# In[10]:


# Calculate summary statistics for level_progress.csv
print(level_progress.describe())


# ### Visualisations of EDA

# In[11]:


px.histogram(players, x="system_memory", nbins=20, title="Distribution of System Memory")


# In[12]:


# Create a scatter plot of screen size vs. system memory
px.scatter(players, x="screen_size", y="system_memory", color="platform", title="Screen Size vs. System Memory")


# In[13]:


# Create a bar chart of the most common countries and platforms
top_countries = players["country"].value_counts().head(10)
px.bar(top_countries, x=top_countries.index, y=top_countries.values, title="Top 10 Countries", color= 'country')


# In[14]:


# plot platform and screen size distributions
fig2, axes = plt.subplots(nrows=1, ncols=2, figsize=(10,5))
sns.countplot(x='platform', data=players, ax=axes[0])
sns.histplot(x='screen_size', data=players, bins=10, ax=axes[1])
fig2.suptitle('Player Platform and Screen Size Distributions')
plt.show()


# ### Merging the data

# In[15]:


merged_data = pd.merge(players, level_progress, on='player_id')


# In[16]:


merged_data.head()


# In[20]:


# calculate the percentage of players who complete each level
level_completion_df = merged_data[merged_data['status'] == 'complete'].groupby('level_number')['player_id'].nunique().reset_index()
level_completion_df['completion_rate'] = level_completion_df['player_id'] / merged_data['player_id'].nunique() * 100
level_completion_df['completion_rate'].head()


# ### Calculating Churn rate

# In[21]:


# Calculate the total number of players
total_players = merged_data['player_id'].nunique()
total_players


# In[22]:


# Calculate the number of players who completed at least one level
completed_players = merged_data[merged_data['status'] == 'complete']['player_id'].nunique()
completed_players


# In[23]:


# Calculate the churn rate
churn_rate = (total_players - completed_players) / total_players
print(f"The churn rate is: {round(churn_rate * 100, 2)}%")


# In[24]:


# plot churn rate
fig1 = px.pie(values=[churn_rate, 1-churn_rate], names=['Churned Players', 'Active Players'], title='Overall Player Retention Rate')
fig1.show()


# In[121]:


# Create a DataFrame with the number of stages, number of fails, and number of completes for each level
level_results = merged_data.groupby(['level_number', 'status']).agg({'stage_number': 'count'}).reset_index()
level_results = level_results.pivot(index='level_number', columns='status', values='stage_number')
level_results.fillna(0, inplace=True)


# In[122]:


# Add a column for the total number of stages
level_results['total_stages'] = level_results.sum(axis=1)


# In[123]:


# Add a column for the fail rate
level_results['fail_rate'] = level_results['fail'] / level_results['total_stages']


# In[124]:


# Add a column for the complete rate
level_results['complete_rate'] = level_results['complete'] / level_results['total_stages']


# In[125]:


# Create a line chart for the fail rate and complete rate by level
fig = make_subplots(specs=[[{"secondary_y": True}]])
fig.add_trace(go.Scatter(x=level_results.index, y=level_results['fail_rate'], name="Fail Rate"))
fig.add_trace(go.Scatter(x=level_results.index, y=level_results['complete_rate'], name="Complete Rate"))
fig.update_layout(title='Fail Rate and Complete Rate by Level', xaxis_title='Level Number',
                  yaxis_title='Rate', legend_title='Status')
fig.show()


# ### Churn rate by level and status

# In[70]:


# Convert datetime columns to datetime objects
merged_data['install_datetime'] = pd.to_datetime(merged_data['install_datetime'])
merged_data['event_datetime'] = pd.to_datetime(merged_data['event_datetime'])


# In[ ]:


# Calculate churn rate by level and status
grouped = level_progress.groupby(['level_number', 'status'])['player_id'].nunique().reset_index()
grouped['churned'] = grouped.apply(lambda x: x['player_id'] if x['status'] == 'fail' else 0, axis=1)
grouped['total_players'] = grouped.groupby('level_number')['player_id'].transform('sum')
grouped['churn_rate'] = grouped['churned'] / grouped['total_players']


# In[130]:


# Filter for failed events
filtered = grouped[grouped['status'] == 'fail']


# In[131]:


# Visualize the results using a stacked area chart
fig1 = px.area(filtered, x='level_number', y='churn_rate', color='status',
              title='Churn rate by level and status')
fig1.update_layout(yaxis_tickformat='%')
fig1.show()


# In[115]:


# Calculate the proportion of players who fail a level and subsequently stop playing
fail_and_churn = merged_data.loc[merged_data['status'] == 'fail'].groupby('level_number')['player_id'].nunique()
fail_and_churn /= merged_data.loc[merged_data['status'] == 'fail'].groupby('level_number')['player_id'].nunique() + merged_data.loc[merged_data['status'] == 'complete'].groupby('level_number')['player_id'].nunique()


# In[116]:


# Calculate the proportion of players who successfully complete a level and continue playing
complete_and_stay = merged_data.loc[merged_data['status'] == 'complete'].groupby('level_number')['player_id'].nunique()
complete_and_stay /= merged_data.loc[merged_data['status'] == 'fail'].groupby('level_number')['player_id'].nunique() + merged_data.loc[merged_data['status'] == 'complete'].groupby('level_number')['player_id'].nunique()


# In[117]:


# Create a bar chart to compare the proportions
fig = go.Figure()
fig.add_trace(go.Bar(x=fail_and_churn.index, y=fail_and_churn, name='Fail and Churn'))
fig.add_trace(go.Bar(x=complete_and_stay.index, y=complete_and_stay, name='Complete and Stay'))
fig.update_layout(title='Proportion of Players who Fail a Level and subsequently Churn, compared to those who Complete the Level and Stay',
                  xaxis_title="Level Number", yaxis_title="Proportion of Players")
fig.show()


# In[127]:


# Filter to only include complete and fail events
merged_data = merged_data[merged_data["status"].isin(["complete", "fail"])]


# In[128]:


# Calculate proportion of players who stop playing after completing or failing a level
proportions = merged_data.groupby(["level_number", "status"])["player_id"].nunique() / merged_data.groupby(["level_number"])["player_id"].nunique()


# In[129]:


# Plot the proportions
fig = go.Figure()
fig.add_trace(go.Bar(x=proportions.loc[:, "fail"].index, y=proportions.loc[:, "fail"], name="Fail"))
fig.add_trace(go.Bar(x=proportions.loc[:, "complete"].index, y=proportions.loc[:, "complete"], name="Complete"))
fig.update_layout(title="Proportion of Players Who Stop Playing After Failing or Completing Each Level",
                  xaxis_title="Level Number", yaxis_title="Proportion of Players", barmode="stack")
fig.show()

